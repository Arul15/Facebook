//
//  FBImageViewController_DemoTests.h
//  FBImageViewController_DemoTests
//
//  Created by Michael henry Pantaleon on 5/31/13.
//  Copyright (c) 2013 Michael Henry Pantaleon. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface FBImageViewController_DemoTests : SenTestCase

@end
