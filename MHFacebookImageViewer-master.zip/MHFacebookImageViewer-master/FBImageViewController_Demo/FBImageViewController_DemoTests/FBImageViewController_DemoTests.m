//
//  FBImageViewController_DemoTests.m
//  FBImageViewController_DemoTests
//
//  Created by Michael henry Pantaleon on 5/31/13.
//  Copyright (c) 2013 Michael Henry Pantaleon. All rights reserved.
//

#import "FBImageViewController_DemoTests.h"

@implementation FBImageViewController_DemoTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in FBImageViewController_DemoTests");
}

@end
